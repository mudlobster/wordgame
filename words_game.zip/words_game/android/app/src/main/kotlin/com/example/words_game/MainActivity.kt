package com.example.words_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
