


//lay out the UI

//write down the logic of the game
//generate a set of random letters from a list of allowed letters

// var list = ['a','b','c','e','h','m','o','p','t','k','i','r','s','n','d','u'];
//
// final _random = new Random();
//
// var n1 = list[_random.nextInt(list.length)];
// var n2 = list[_random.nextInt(list.length)];
// var n3 = list[_random.nextInt(list.length)];




//match the player's input against the ReGex to check whether it follows the pattern

// final check_regex = RegExp('^(.*)($n1)(.*)($n2)(.*)($n3)(.*)\$');
// var check = check_regex.hasMatch(_payerInput);


//if the word follows the pattern, check whether it belongs to a list of English words
//if it belongs to a list of words, give player points and generate a new set of random letters

